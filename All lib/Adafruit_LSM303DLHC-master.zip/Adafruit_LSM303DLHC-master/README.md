# Adafruit LSM303DLHC Driver (Accelerometer + Magnetometer)

This library has been replaced by the following libraries and will no longer be supported. Please switch to the new libraries.

[Adafruit_LSM303_Accel](https://github.com/adafruit/Adafruit_LSM303_Accel) for the accelerometer and

[Adafruit_LSM303DLH_Mag](https://github.com/adafruit/Adafruit_LSM303DLH_Mag) for the magnetometer.

To use the new libraries, consult [the LSM303 guide on the Adafruit Learning System](https://learn.adafruit.com/lsm303-accelerometer-slash-compass-breakout/coding) for more info


